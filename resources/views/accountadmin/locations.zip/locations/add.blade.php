@extends('layouts.dashboard')

@section('content')
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h4 class="text-themecolor">Dashboard</h4>
            </div>
            <div class="col-md-7 align-self-center text-end">
                <div class="d-flex justify-content-end align-items-center">
                    <ol class="breadcrumb justify-content-end">
                      <li class="breadcrumb-item"><a href="/accountadmin">Home</a></li>
                      <li class="breadcrumb-item active"><a href="/accountadmin/locations">Location</a></li>
                    </ol>
                    <button type="button" class="btn btn-info d-none d-lg-block m-l-15 text-white"><i class="fa fa-plus-circle"></i> Create New Location</button>
                </div>
            </div>
        </div>
        <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">{{ isset($getLocation) && ($getLocation->pk_locations) ? 'Edit Location':'Create New Location'}}</h4>
                                <div class="tab-content br-n pn">
                                    <div id="navpills-1" class="tab-pane active">
                                        <div class="row">
                                          @if(Session::has('message'))
                                            <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
                                          @endif
                                          <form class="form-horizontal mt-4 " method="post" action="{{isset($getLocation) && ($getLocation->pk_locations) ? '/accountadmin/locations/update' : '/accountadmin/locations/submit'}}">
                                            @csrf
                                            <div class="form-group">
                                                <label for="location_name">Location Name</label>
                                                <input type="text" name="location_name" class="form-control @error('location_name') is-invalid @enderror" value="{{ isset($getLocation) && ($getLocation->location_name) ? $getLocation->location_name : old('location_name')}}">
                                                @error('location_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label for="location_name">Location Code</label>
                                                <input type="text" name="location_code" class="form-control @error('location_code') is-invalid @enderror" value="{{ isset($getLocation) && ($getLocation->location_code) ? $getLocation->location_code : old('location_code')}}">
                                                @error('location_code')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class ="row">
                                            <div class ="col-md-6">
                                            <div class="form-group">
                                                <label for="location_name">Address</label>
                                                <input type="text" name="address" class="form-control @error('address') is-invalid @enderror" value="{{ isset($getLocation) && ($getLocation->address) ? $getLocation->address : old('location_code')}}">
                                                @error('address')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            </div>
                                            <div class ="col-md-6">
                                            <div class="form-group">
                                                <label for="location_name">Ste#</label>
                                                <input type="text" name="address_1" class="form-control @error('address_1') is-invalid @enderror" value="{{ isset($getLocation) && ($getLocation->address_1) ? $getLocation->address_1 : old('location_code')}}" maxlength="10">
                                                @error('address_1')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                          </div>
                                          </div>
                                          <div class ="row">
                                            <div class ="col-md-4">
                                              <div class="form-group">
                                                  <label for="location_name">City</label>
                                                  <input type="text" name="city" class="form-control @error('city') is-invalid @enderror" value="{{ isset($getLocation) && ($getLocation->city) ? $getLocation->city : old('city')}}">
                                                  @error('city')
                                                      <span class="invalid-feedback" role="alert">
                                                          <strong>{{ $message }}</strong>
                                                      </span>
                                                  @enderror
                                              </div>
                                            </div>
                                            <div class ="col-md-4">
                                            <div class="form-group">
                                                <label for="location_name">Zip</label>
                                                <input type="text" name="zip" class="form-control @error('zip') is-invalid @enderror" value="{{ isset($getLocation) && ($getLocation->zip) ? $getLocation->city : old('zip')}}">
                                                @error('zip')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            </div>
                                            <div class ="col-md-4">
                                              <div class="form-group">
                                                  <label for="role">State</label>
                                                  <select name="pk_states" id="pk_states" class="form-control @error('pk_states') is-invalid @enderror">
                                                      <option value="">Choose...</option>
                                                      @foreach($states as $state)
                                                          <option value="{{ $state->pk_states }}" {{ isset($getLocation) && ($getLocation->pk_states  == $state->pk_states) ? 'selected' : '' }}>{{ $state->state_code }}</option>
                                                      @endforeach
                                                  </select>
                                                  @error('pk_states')
                                                      <span class="invalid-feedback" role="alert">
                                                          <strong>{{ $message }}</strong>
                                                      </span>
                                                  @enderror
                                              </div>
                                          </div>
                                         </div>
                                         <div class="form-group">
                                             <label for="role">Country</label>
                                             <select name="pk_country" id="pk_country" class="form-control @error('pk_country') is-invalid @enderror" >
                                                 <option value="">Choose...</option>
                                                 @foreach($countries as $country)
                                                     <option value="{{ $country->pk_country }}" {{ isset($getLocation) && ($getLocation->pk_country  == $country->pk_country) ? 'selected' : '' }}>{{ $country->country_code }}</option>
                                                 @endforeach
                                             </select>
                                             @error('pk_country')
                                                 <span class="invalid-feedback" role="alert">
                                                     <strong>{{ $message }}</strong>
                                                 </span>
                                             @enderror
                                         </div>
                                            <div class="form-group">
                                                <label for="role">Timezone</label>
                                                <select name="pk_timezone" id="pk_timezone" class="form-control @error('pk_timezone') is-invalid @enderror" >
                                                    <option value="">Choose...</option>
                                                    @foreach($timezones as $timezone)
                                                        <option value="{{ $timezone->pk_timezone }}" {{ isset($getLocation) && ($getLocation->pk_timezone  == $timezone->pk_timezone) ? 'selected' : '' }}>{{ $timezone->name }}</option>
                                                    @endforeach
                                                </select>
                                                @error('pk_timezone')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label">Active</label>
                                                    <input type="radio" name="active"  value="1" checked="checked" class="form-check-input" style="margin-left: 20px;">
                                                    <label class="form-check-label" for="customRadio11">Yes</label>
                                                    <input type="radio" name="active" value="0" {{ isset($getLocation) && ($getLocation->active=="0")? "checked" : "" }} class="form-check-input" style="margin-left: 20px;">
                                                    <label class="form-check-label" for="customRadio22">No</label>
                                            </div>
                                            <input type="hidden" name="pk_locations" class="form-control" value="{{isset($getLocation) && ($getLocation->pk_locations)?$getLocation->pk_locations:''}}">
                                            @if(isset($getLocation) && ($getLocation->pk_account))
                                            <input type="hidden" name="pk_account" class="form-control" value="{{isset($getLocation) && ($getLocation->pk_account) ? $getLocation->pk_account :''}}">
                                            @else
                                            <input type="hidden" name="pk_account" class="form-control" value="{{isset($account) && !empty($account) ? $account:''}}">
                                            @endif
                                             <a href="/accountadmin/locations/back"><input class="btn btn-primary" type="button" value="Cancel"></a>
                                            <input class="btn btn-primary" type="submit" value="Submit">
                                          </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>
</div>

@endsection
